// Replace with your own firebase config!
export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCGSy4X-7258XMT3LLO6Ymz3i-mvEaZFJA",
  authDomain: "covod-19.firebaseapp.com",
  databaseURL: "https://covod-19.firebaseio.com",
  projectId: "covod-19",
  storageBucket: "covod-19.appspot.com",
  messagingSenderId: "454261671253",
  appId: "1:454261671253:web:96d2ffe879bffebc835bdc",
  measurementId: "G-S0YYEXKSKN"
};
